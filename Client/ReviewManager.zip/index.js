import { useState, useMemo, useRef, useEffect } from 'react';
import { Table, DatePicker, Button, Select } from 'antd';
import { ArrowLeftOutlined, CalendarOutlined, DownloadOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';

import styles from './ReviewManager.module.scss';
import PhotoModal from './PhotoModal.js';
import SpecRangeModal from './SpecRangeModal.js';
import {
  HARVEST_OPTIONS, MAIN_TABS, SUB_TABS, OI_SUB_TABS,
  OI_BASE_COLS, TAB_CONFIG, OI_TAB_CONFIG,
} from './constants.js';
import {
  ValueCell, ActionPill,
  makeNumericSorter, renderExtraCell,
  HARVEST_BASE_COLS,
} from './helpers.js';

const { RangePicker } = DatePicker;

export default function ReviewManager() {
  const navigate = useNavigate();

  const [activeMainTab,  setActiveMainTab]  = useState(0);
  const [activeSubTab,   setActiveSubTab]   = useState(0);
  const [harvest,        setHarvest]        = useState('pre-harvest');
  const [dateRange,      setDateRange]      = useState([dayjs('2026-01-01'), dayjs('2026-01-04')]);
  const [selectedOIKeys, setSelectedOIKeys] = useState(new Set());
  const [photoModal,     setPhotoModal]     = useState(null);
  const [specModal,      setSpecModal]      = useState(null);

  const detailsTbodyRef = useRef(null);
  const paramsTbodyRef  = useRef(null);

  const isOI          = activeMainTab === 1;
  const currentSubTabs = isOI ? OI_SUB_TABS : SUB_TABS;
  const activeTabName = currentSubTabs[activeSubTab];
  const config        = isOI
    ? (OI_TAB_CONFIG[activeTabName] ?? { extraCols: [], valueCols: [], actionLabel: 'Action', data: {} })
    : (TAB_CONFIG[activeTabName]    ?? { extraCols: [], valueCols: [], actionLabel: 'Action', data: {} });
  const tableData = config.data[harvest] ?? [];

  // OI checkbox helpers
  const allOISelected  = tableData.length > 0 && tableData.every(r => selectedOIKeys.has(r.key));
  const someOISelected = tableData.some(r => selectedOIKeys.has(r.key));
  const toggleAllOI    = () => setSelectedOIKeys(allOISelected ? new Set() : new Set(tableData.map(r => r.key)));
  const toggleOIKey    = key => setSelectedOIKeys(prev => {
    const s = new Set(prev);
    s.has(key) ? s.delete(key) : s.add(key);
    return s;
  });

  // Reset checkboxes on tab / harvest change
  useEffect(() => { setSelectedOIKeys(new Set()); }, [activeMainTab, activeTabName, harvest]);

  // Sync row heights + sticky-right offsets for Status / Action columns
  useEffect(() => {
    if (!isOI || !detailsTbodyRef.current || !paramsTbodyRef.current) return;

    const dRows = [...detailsTbodyRef.current.querySelectorAll('tr')];
    const pRows = [...paramsTbodyRef.current.querySelectorAll('tr')];
    dRows.forEach(r => (r.style.height = ''));
    pRows.forEach(r => (r.style.height = ''));
    const len = Math.min(dRows.length, pRows.length);
    for (let i = 0; i < len; i++) {
      const h = Math.max(dRows[i].offsetHeight, pRows[i].offsetHeight) + 'px';
      dRows[i].style.height = h;
      pRows[i].style.height = h;
    }

    const pTable = paramsTbodyRef.current.closest('table');
    if (pTable && pRows.length > 0) {
      const firstBodyCells = pRows[0].querySelectorAll('td');
      const actionW = firstBodyCells[firstBodyCells.length - 1]?.offsetWidth ?? 0;
      [...pTable.querySelectorAll('thead tr, tbody tr')].forEach(row => {
        const cells = row.querySelectorAll('th, td');
        const n = cells.length;
        if (n >= 1) cells[n - 1].style.right = '0px';
        if (n >= 2) cells[n - 2].style.right = actionW + 'px';
      });
    }
  }, [isOI, activeTabName, harvest, tableData]);

  const columns = useMemo(() => {
    const baseCols  = isOI
      ? OI_BASE_COLS
      : (HARVEST_BASE_COLS[harvest] ?? HARVEST_BASE_COLS['pre-harvest']);
    const rawExtra  = Array.isArray(config.extraCols)
      ? config.extraCols
      : (config.extraCols[harvest] ?? config.extraCols['default'] ?? []);
    const extraCols = rawExtra.map(({ key, label, sorter }) => ({ title: label, dataIndex: key, key, sorter }));
    const valueCols = config.valueCols.map(({ key, label }) => ({
      title: label, dataIndex: key, key,
      sorter: makeNumericSorter(key),
      render: (val) => <ValueCell data={val} />,
    }));
    const statusCol = {
      title: 'Status', dataIndex: 'status', key: 'status',
      render: (val) => (
        <span className={`${styles.statusBadge} ${val === 'Pass' ? styles.statusPass : styles.statusFail}`}>{val}</span>
      ),
    };
    const actionCol = {
      title: config.actionLabel, dataIndex: 'action', key: 'action',
      render: (val) => <ActionPill action={val} />,
    };
    return [...baseCols, ...extraCols, ...valueCols, statusCol, actionCol];
  }, [activeMainTab, activeTabName, harvest]);

  return (
    <div className={styles.container}>

      {/* Breadcrumb */}
      <div className={styles.breadcrumb}>
        <span className={styles.breadcrumbLink} onClick={() => navigate('/dashboard')}>Home Screen</span>
        <span className={styles.breadcrumbSep}>&gt;</span>
        <span className={styles.breadcrumbLink} onClick={() => navigate('/quality-control')}>Quality Control</span>
        <span className={styles.breadcrumbSep}>&gt;</span>
        <span>{isOI ? 'Organoleptic Inspection - Review Manager' : 'Lab Test - Review Manager'}</span>
      </div>

      {/* Page header */}
      <div className={styles.pageHeader}>
        <div className={styles.headerLeft}>
          <button type="button" className={styles.backBtn} onClick={() => navigate(-1)}>
            <ArrowLeftOutlined />
          </button>
          <h1 className={styles.pageTitle}>
            {isOI ? 'Organoleptic Inspection - Review Manager' : 'Lab Test - Review Manager'}
          </h1>
        </div>
        <div className={styles.headerRight}>
          <RangePicker
            value={dateRange}
            onChange={setDateRange}
            format="MM/DD/YYYY"
            className={styles.datePicker}
            suffixIcon={<CalendarOutlined />}
          />
          {!isOI && (
            <Select
              value={harvest}
              onChange={setHarvest}
              options={HARVEST_OPTIONS}
              className={styles.harvestSelect}
            />
          )}
          <button className={styles.iconBtn}><DownloadOutlined /></button>
        </div>
      </div>

      {/* Card — tabs + table */}
      <div className={styles.card}>
        <div className={styles.mainTabs}>
          {MAIN_TABS.map((tab, i) => (
            <button
              key={tab}
              className={`${styles.mainTab} ${activeMainTab === i ? styles.mainTabActive : ''}`}
              onClick={() => { setActiveMainTab(i); setActiveSubTab(0); }}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className={styles.subTabsWrapper}>
          <div className={styles.subTabs}>
            {currentSubTabs.map((tab, i) => (
              <button
                key={tab}
                className={`${styles.subTab} ${activeSubTab === i ? styles.subTabActive : ''}`}
                onClick={() => setActiveSubTab(i)}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className={styles.tableWrapper}>
          {isOI ? (
            <div className={styles.splitTableWrapper}>

              {/* Details pane — checkbox + base cols + extra cols */}
              <div className={`${styles.detailsPane} ${config.hideParams ? styles.detailsPaneFull : ''}`}>
                <table className={styles.oiTable}>
                  <thead>
                    <tr>
                      <th className={`${styles.oiTh} ${styles.checkboxTh}`}>
                        <input
                          type="checkbox"
                          className={styles.checkbox}
                          checked={allOISelected}
                          ref={el => { if (el) el.indeterminate = someOISelected && !allOISelected; }}
                          onChange={toggleAllOI}
                        />
                      </th>
                      {[...(config.baseCols ?? OI_BASE_COLS), ...config.extraCols].map(col => (
                        <th key={col.key} className={styles.oiTh}>{col.title ?? col.label}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody ref={detailsTbodyRef}>
                    {tableData.map(row => (
                      <tr key={row.key}>
                        <td className={`${styles.oiTd} ${styles.oiTdDetail} ${styles.checkboxTd}`}>
                          <input
                            type="checkbox"
                            className={styles.checkbox}
                            checked={selectedOIKeys.has(row.key)}
                            onChange={() => toggleOIKey(row.key)}
                          />
                        </td>
                        {(config.baseCols ?? OI_BASE_COLS).map(col => (
                          <td key={col.key} className={`${styles.oiTd} ${styles.oiTdDetail}`}>
                            {col.type
                              ? renderExtraCell(row, col, { onPhotoView: setPhotoModal, onSpecsView: setSpecModal })
                              : (row[col.dataIndex ?? col.key] ?? '-')}
                          </td>
                        ))}
                        {config.extraCols.map(col => (
                          <td key={col.key} className={`${styles.oiTd} ${styles.oiTdDetail}`}>
                            {renderExtraCell(row, col, { onPhotoView: setPhotoModal, onSpecsView: setSpecModal })}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Params pane — value cols + sticky Status + Action */}
              {!config.hideParams && (
              <div className={styles.paramsPane}>
                <table className={styles.oiTable}>
                  <thead>
                    <tr>
                      {config.valueCols.map(col => (
                        <th key={col.key} className={styles.oiTh}>{col.label}</th>
                      ))}
                      <th className={`${styles.oiTh} ${styles.stickyRight}`}>Status</th>
                      <th className={`${styles.oiTh} ${styles.stickyRight}`}>{config.actionLabel}</th>
                    </tr>
                  </thead>
                  <tbody ref={paramsTbodyRef}>
                    {tableData.map(row => (
                      <tr key={row.key}>
                        {config.valueCols.map(col => (
                          <td key={col.key} className={styles.oiTd}>
                            <ValueCell data={row[col.key]} />
                          </td>
                        ))}
                        <td className={`${styles.oiTd} ${styles.stickyRightTd}`}>
                          <span className={`${styles.statusBadge} ${row.status === 'Pass' ? styles.statusPass : styles.statusFail}`}>
                            {row.status}
                          </span>
                        </td>
                        <td className={`${styles.oiTd} ${styles.stickyRightTd}`}>
                          <ActionPill action={row.action} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              )}

            </div>
          ) : (
            <Table
              rowSelection={{ type: 'checkbox' }}
              columns={columns}
              dataSource={tableData}
              pagination={false}
              className={styles.table}
              showSorterTooltip={false}
            />
          )}
        </div>
      </div>

      {/* Footer */}
      <div className={styles.footerActions}>
        <Button type="primary" className={styles.previewBtn}>Reviewed</Button>
      </div>

      {/* Photo view modal */}
      <PhotoModal row={photoModal} onClose={() => setPhotoModal(null)} />

      {/* Spec Range modal */}
      <SpecRangeModal row={specModal} onClose={() => setSpecModal(null)} />

    </div>
  );
}
